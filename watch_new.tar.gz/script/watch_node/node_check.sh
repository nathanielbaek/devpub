#!/bin/bash

PARENT_PID="$1"
SLOT="$2"
DATA_DIRECTORY="/home/klaytn/data"
SCRIPT_DIR="/tree/script/watch_node"
LOG_DIR="/tree/script/watch_node/log/$SLOT"
NODE_KNI_SHORT="xxxx"

kscn attach --datadir $DATA_DIRECTORY --exec admin.nodeInfo > $LOG_DIR/admin_nodeinfo.log
cat $DATA_DIRECTORY/static-nodes.json | awk -F "//" '{print $2}' | awk -F "@" '{print $1 " " $2}' | awk 'NF' > $LOG_DIR/static-nodes.log

while true; do
  echo "" > $LOG_DIR/node_connection.bak

  kscn attach --datadir $DATA_DIRECTORY --exec admin.peers | grep id > $LOG_DIR/admin_peers.log
  cat $LOG_DIR/admin_peers.log | awk -F "\"" '{print $2}' | grep -o '^.....' | awk '{print "[?] "$1"..."}' > $LOG_DIR/check_unknown_peers.log

  while IFS= read -r line; do
   #kspn attach --datadir $DATA_DIRECTORY --exec admin.peers > $LOG_DIR/admin_peers.log
    NODE_NAME=$(echo $line | awk '{print $1}')
    NODE_KNI=$(echo $line | awk '{print $2}')
    NODE_IP=$(echo $line | awk '{print $3}')

    NODE_KNI_SHORT=$(echo $NODE_KNI | grep -o '^.....')
    sed -i "/$NODE_KNI_SHORT/d" $LOG_DIR/check_unknown_peers.log

    CHECK_STATIC_NODES=$(cat "$LOG_DIR"/static-nodes.log | grep -i $NODE_KNI | wc -l)
    if [ $CHECK_STATIC_NODES -gt 0 ]
    then
      ## CHECK NODE CONNECTION 
      CHECK_CURRENT_NODE=$(cat "$LOG_DIR"/admin_nodeinfo.log | grep -i $NODE_KNI | wc -l)
      CHECK_PEERS=$(cat "$LOG_DIR"/admin_peers.log | grep -i $NODE_KNI | wc -l)

      if [ $CHECK_CURRENT_NODE -gt 0 ]
      then
        echo "    $NODE_NAME   " >> $LOG_DIR/node_connection.bak
      else
        if [ $CHECK_PEERS -gt 0 ]
        then
          echo "[O] $NODE_NAME   " >> $LOG_DIR/node_connection.bak
        else
          echo "[-] $NODE_NAME   " >> $LOG_DIR/node_connection.bak
        fi
      fi

      ## KILL THE CURRENT PROCESS WHEN THE PARENT PROCESS IS KILLED
      PARENT_PROCESS_CHECK=$(ps -ef | awk '{print $2}' | grep $PARENT_PID | wc -l)
      if [ $PARENT_PROCESS_CHECK -eq 0 ]
      then
        #rm -rf $LOG_DIR
        exit 0
      fi
    fi
done < $SCRIPT_DIR/node_info 

cat "$LOG_DIR"/node_connection.bak > $LOG_DIR/node_connection ; cat "$LOG_DIR"/check_unknown_peers.log >>$LOG_DIR/node_connection

done
