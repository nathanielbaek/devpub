#!/bin/bash

HOSTNAME=$(hostname)
DATA_DIRECTORY="/home/klaytn/data/"
SCRIPT_DIR="/tree/script/watch_node"
LOG_DIR="/tree/script/watch_node/log"
PARENT_PID=$$


mkdir -p $SCRIPT_DIR ; mkdir -p $LOG_DIR

# CREATE LOG DIRECTORY
SLOT=1
while true
do
 CHECK_LOG_DIRECTORY=$(ls -ald "$LOG_DIR"/"$SLOT" 2> /dev/null | wc -l)  
 if [ $CHECK_LOG_DIRECTORY -eq 0 ]
 then
   mkdir -p $LOG_DIR/$SLOT
   break
 else
   SLOT=$((SLOT+1))
 fi
done

# SAVE CURRENT BASH SCRIPT PID
echo "$PARENT_PID" > "$LOG_DIR"/"$SLOT"/watch_node_PID

# RUN BACKGROUND SCRIPT (CHECK PEERS)
sh $SCRIPT_DIR/node_check.sh $PARENT_PID $SLOT &

# CHECK NODE STATUS (BLOCK_NUMBER, PEERS_COUNT, PEERS_INFO)  (1s)
watch -t -n1 "echo [$HOSTNAME] ; kscn attach --datadir $DATA_DIRECTORY --exec klay.blockNumber ; kscn attach --datadir $DATA_DIRECTORY --exec net.peerCount ; cat $LOG_DIR/$SLOT/node_connection"
